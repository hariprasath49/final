# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Metarial Issue request',
    'version': '1',
    'category': 'Manufacturing',
    'sequence': 1,
    'summary': 'Extend program',
    'description': """""",
    'website': 'https://www.odoo.com/page/',
    'depends': ['sale','mrp'],
    'data': [
        'data/ir_sequence.xml',
        'views/material_request.xml',
        
        
                
            ],
   'installable': True,
   'application': True,
  
}
