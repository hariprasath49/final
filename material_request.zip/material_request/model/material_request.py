from odoo import models, fields, api, _
from datetime import datetime
from dateutil.relativedelta import relativedelta

class MaterialRequest(models.Model):
    _name = 'material.request'
    
    def _get_default_location_id(self):
        return self.env.ref('stock.stock_location_stock', raise_if_not_found=False)

    def _get_default_location_dest_id(self):
        return self.env.ref('stock.stock_location_stock', raise_if_not_found=False)
    
    name = fields.Char(readonly=True,required=True, copy=False, default='New')
    requester_name = fields.Many2one('res.partner',string="Name",required=True)
    date_of_request = fields.Date(string="Date Of Request")
    product_ids = fields.One2many('material.request.line','product_id',string="Product")
    picking_type_id = fields.Many2one('stock.picking.type', string="Picking Type",required=True)
    move_type = fields.Selection([('direct', 'Partial'), ('one', 'All at Onces')], String='Delivery Type', default='direct',required=True)
    location_id = fields.Many2one('stock.location',default=_get_default_location_id,string="Production Location",required=True)
    location_dest_id = fields.Many2one('stock.location', 'Destination Location',default=_get_default_location_dest_id,required=True)
    
    
    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('material.request') or 'New'
        result = super(MaterialRequest, self).create(vals)
        return result
    
    @api.multi
    def issue_product(self):
        
        list=[]
        for rec in self.product_ids:
            material_request = self.env['stock.picking'].create({
                        'name':rec.seller_ids[0].name,
                        'partner_id':rec.requester_name.id,
                        'min_date':rec.date_of_request,
                        'move_type':rec.move_type,
                        'picking_type_id':rec.picking_type_id.id,
                        'location_id':rec.location_id.id,
                        'location_dest_id':rec.location_dest_id.id,
                        'move_lines': [(0,0, { 'product_id':rec.product_id.id,
                                                'date': rec.create_date,
                                                'product_uom_qty': rec.product_uom_qty,
                                                'product_uom': rec.product_uom.id,
                                                'location_id':rec.location_id.id,
                                                'location_dest_id':rec.location_dest_id.id,
                                                })]
                                        })
    

class MaterialRequestLine(models.Model):
    _name = 'material.request.line'
    def _get_default_location_id(self):
        return self.env.ref('stock.stock_location_stock', raise_if_not_found=False)
    def _get_default_location_dest_id(self):
        return self.env.ref('stock.stock_location_stock', raise_if_not_found=False)
    
    product_id = fields.Many2one('product.product',string="Product")
    product_uom_qty = fields.Float(string="Quantity Required",required=True)
    price_unit = fields.Float(string="Unit Price")
    product_uom = fields.Many2one('product.uom', string='Unit of Measure', required=True)
    location_id = fields.Many2one('stock.location', 'Production Location',default=_get_default_location_id,required=True)
    create_date = fields.Date(string='Current Date', default=datetime.today())
    location_dest_id = fields.Many2one('stock.location', 'Destination Location',default=_get_default_location_dest_id,required=True)
